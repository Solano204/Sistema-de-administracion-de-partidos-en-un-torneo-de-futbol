-- Update categories logo_url
UPDATE fut_jaguar.categories 
SET logo_url = 'https://dxfjdqqppxfoobevbubc.supabase.co/storage/v1/object/public/fut-next-images/CategoriesImages/Sub21Back.jpeg';

-- Update users photo_url
UPDATE fut_jaguar.users 
SET photo_url = 'https://dxfjdqqppxfoobevbubc.supabase.co/storage/v1/object/public/fut-next-images/CategoriesImages/6093ce07e9ff71569a60ebd1-1.jpg';
-- Update teams logo_url
UPDATE fut_jaguar.teams 
SET logo_url = 'https://dxfjdqqppxfoobevbubc.supabase.co/storage/v1/object/public/fut-next-images/CategoriesImages/vlicwlpagkmii0suwzjg.png';

-- Update players photo_url
UPDATE fut_jaguar.players 
SET photo_url = 'https://dxfjdqqppxfoobevbubc.supabase.co/storage/v1/object/public/fut-next-images/CategoriesImages/messi-foto-redes-sociales.jpg';